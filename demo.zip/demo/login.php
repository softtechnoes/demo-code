<?php
 include('connect.php');
session_start();
?>
<html>
    <head>
        <title>form</title>
        <link rel="stylesheet" href="style.css">
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    </head>
</html>
<body>
    <div class="container">
        <h1 style="margin-left:450px;margin-top:30px;color:red;">LOGIN</h1>
       <?php 
       if(isset($_POST['submit']))
       {
       $email=$_POST['email'];
       $password=$_POST['password'];
    $query=mysqli_query($conn,"SELECT * FROM `details` WHERE email='$email' and password='$password'");
    $num=mysqli_num_rows($query);
    if($num>0)
    {
        $fetch=mysqli_fetch_array($query);
        $id=$fetch['srno'];
        $_SESSION['srno']=$id;
    }

       }
       ?>
       
    <div class="div">
        <form method="post" action="formm.php">
           
        <label class="la">EM@IL</label><br>
            <input type="text" placeholder="your email" name="email" class="fo" required>   
                <label class="la">password</label><br>
            <input type="password" placeholder="Password" name="password"class="fo" required>
           
            <button type="submit" name="submit" class="btn btn-primary la fo" style="margin-top:30px">SUBMIT</button>
        </form>
    </div>
</div>
</body>
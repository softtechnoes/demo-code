<?php
 include('connect.php');
 session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2  style="color:red;margin-left:450px;margin-top:30px">DETAILS:</h2>
  
        
  <table class="table table-bordered">
    <thead>
      <tr>
      <th>srno</th>
        <th>Name</th>
        <th>Father's name</th>
        <th>Address</th>
        <th>Email</th>
        <th>Phone</th>
        <th colspan="2">action</th>

      </tr>
    </thead>
    <?php
    $sr=1;
    $id=$_SESSION['srno'];
    $query=mysqli_query($conn,"SELECT * FROM `details` WHERE  srno='$id'")or die (mysqli_error($conn));
    while($fetch=mysqli_fetch_array($query))
    {
     
    ?>
    <tbody>
      <tr>
        <td><?php echo $sr?></td>
        <td><?php echo $fetch ['name'];?></td>
        <td><?php echo $fetch ['father name'];?></td>
        <td><?php echo $fetch ['address'];?></td>
        <td><?php echo $fetch ['email'];?></td>
        <td><?php echo $fetch ['password'];?></td>
        <td><a href="update.php?id=<?php echo $id?>"><button type="button" value="UPDATE">UPDATE</button></td>
        <td><a href="delete.php?id=<?php echo $id?>"><button type="button" value="delete">DELETE</button></td>
    </tr>
     <?php
 $sr++;
    }
     ?>
      
      <?php
      echo $id;
      ?>
    </tbody>
  </table>
</div>

</body>
</html>

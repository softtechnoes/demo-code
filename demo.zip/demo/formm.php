<?php
 include('connect.php');
?>
<html>
    <head>
        <title>form</title>
        <link rel="stylesheet" href="style.css">
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    </head>
</html>
<body>
    <?php
    if(isset ($_POST['submit']))
    {
        $name=$_POST['name'];
        $fatername=$_POST['fathername'];
        $address=$_POST['address'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $query=mysqli_query($conn,"INSERT INTO `details`(`name`, `father name`, `address`, `email`, `password`) 
        VALUES ('$name','$fatername','$address','$email',' $password')")or die(mysqli_error($conn));
        
        
    }


    ?>

    <div class="container">
        <h1 style="margin-left:450px;margin-top:30px;color:red;">DETAILS</h1>
 <div class="div">
        <form method="post">
            <label class="la">NAME</label><br>
            <input type="text" placeholder="your name"  name="name"class="fo">
            <label class="la"> FATHER'S NAME</label><br>
            <input type="text" placeholder="your fathername"name="fathername"class="fo">
            <label class="la">ADDRESS</label><br>
            <input type="text" placeholder="your address" name="address" class="fo">
            <label class="la">EM@IL</label><br>
            <input type="text" placeholder="your email" name="email"class="fo">
            <label class="la">password</label><br>
            <input type="password" placeholder="password"  name="password" class="fo"><br>
            <button type="submit" name="submit" class="btn btn-primary la fo" style="margin-top:30px">SUBMIT</button>
        </form>
    </div>
</div>
</body>
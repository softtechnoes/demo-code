<?php
include('connect.php');
$id=$_SESSION['srno'];
$query=mysqli_query($conn,"DELETE FROM `details` WHERE srno=$id");
if($query)
{
    echo'<script type="text/javascript">
    alert("delet successfully");
    </script>;'
}

?>
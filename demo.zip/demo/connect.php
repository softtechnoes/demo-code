<?php
$server="localhost";
$user="root";
$password="";
$database="form";
$conn=mysqli_connect($server,$user,$password,$database);
?>
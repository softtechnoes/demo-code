<?php
 include('connect.php');
 session_start();
?>
<html>
    <head>
        <title>form</title>
        <link rel="stylesheet" href="style.css">
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    </head>
</html>
<body>
    <?php 
        $id=$_SESSION['srno'];
$name=$_POST['name'];
$father=$_POST['father name'];
$address=$_POST['address'];
$email=$_POST['email'];
$password=$_POST['password'];
$update=mysqli_query($conn,"UPDATE `details` SET `name`='$name',
`father name`='$father',`address`='$address',`email`='$email',`password`='$password' WHERE srno='$id'");


?>
<?php


    $query=mysqli_query($conn,"SELECT * FROM `details` WHERE srno='$id'");
    $fetch=mysqli_fetch_array($query);
    
    ?>
    <div class="container">
        <h1 style="margin-left:450px;margin-top:30px;color:red;">LOGIN</h1>
        
    <div class="div">
        <form method="post">
            <label class="la">NAME</label><br>
            <input type="text" placeholder="your name"  name="name"class="fo" value="<?php echo $fetch['name'];?>">
            <label class="la"> FATHER'S NAME</label><br>
            <input type="text" placeholder="your fathername" name="fathername"class="fo" value="<?php echo $fetch['father name'];?>">
            <label class="la">ADDRESS</label><br>
            <input type="text" placeholder="your address" name="address" class="fo" value="<?php echo $fetch['address'];?>">
            <label class="la">EM@IL</label><br>
            <input type="text" placeholder="your email" name="email"class="fo" value="<?php echo $fetch['email'];?>">
            <label class="la">Password</label><br>
            <input type="text" placeholder="Password"  name="password" class="fo" value="<?php echo $fetch['password'];?>"><br>
            <button type="submit" name="submit" class="btn btn-primary la fo" style="margin-top:30px">SUBMIT</button>
        </form>
    </div>
</div>
</body>